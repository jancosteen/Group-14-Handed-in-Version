export interface ReservationStatus {
    reservationStatusId : number;
    reservationStatus1: string;//display this instead of the Id
} 