export interface CreateReservationStatus {
    reservationStatus1: string;
}