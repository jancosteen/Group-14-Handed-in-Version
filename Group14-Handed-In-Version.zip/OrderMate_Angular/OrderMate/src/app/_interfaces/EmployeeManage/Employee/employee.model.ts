
export interface Employee {
    employeeId: number;
    employeeidNumber: number;
//    restaurant?:Restaurant;
}