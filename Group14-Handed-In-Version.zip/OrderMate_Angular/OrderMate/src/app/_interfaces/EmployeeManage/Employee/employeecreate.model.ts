export interface CreateEmployee {
    employeeId: number;
    employeeidNumber: number;
   // restaurant? Restaurant;
}