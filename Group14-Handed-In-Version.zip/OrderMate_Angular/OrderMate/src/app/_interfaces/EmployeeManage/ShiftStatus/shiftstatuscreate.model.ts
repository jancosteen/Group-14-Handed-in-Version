export interface CreateShiftStatus{
    shiftstatus: string;
}