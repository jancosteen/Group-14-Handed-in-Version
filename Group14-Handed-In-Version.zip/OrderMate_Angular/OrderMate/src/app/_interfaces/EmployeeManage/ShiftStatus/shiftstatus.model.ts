export interface ShiftStatus{
    shiftstatusId: number;
    shiftstatus: string;
}