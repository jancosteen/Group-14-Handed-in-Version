import {Restaurant} from '../../../_interfaces/Administration/Restaurant/restaurant.model'

export interface QrCode {
    qrCodeId: number;
    Restaurant:Restaurant;
}