export interface CreateSpecial {
    specialStartDate: Date;
    specialEndDate: Date;
    specialName: string;
    specialDescription: string;
}