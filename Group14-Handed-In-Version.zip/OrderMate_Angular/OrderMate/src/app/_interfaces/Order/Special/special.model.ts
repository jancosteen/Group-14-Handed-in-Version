export interface Special {
    specialId: number;
    specialStartDate: Date;
    specialEndDate: Date;
    specialName: string;
    specialDescription: string;

}