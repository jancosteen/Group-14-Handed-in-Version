import { Order } from "../Order/order.model"

export interface CreateOrderStatus {
    orderStatus1:string;
    orderIdFk: number;
}
