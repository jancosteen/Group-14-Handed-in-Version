import { Order } from "../Order/order.model"

export interface OrderStatus {
    orderStatusId:number;
    orderStatus1:string;
    orderIdFk:number 
} 
