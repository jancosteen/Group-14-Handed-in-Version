//import {User} from '../User/user.model';


export interface UserRoles {
    id: string;
 
    name:string;
    normalizedName:string;
} 