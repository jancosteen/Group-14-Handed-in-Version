export interface CreateUserRoles {
   
    name:string;
    normalizedName:string;
}  