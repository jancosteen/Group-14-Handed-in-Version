//import {Restaurant} from '../Restaurant/restaurant.model';

export interface RestaurantStatus{
    restaurantstatusId: number;
    restaurantStatus1:string;
   // restaurantId?: Restaurant;
}