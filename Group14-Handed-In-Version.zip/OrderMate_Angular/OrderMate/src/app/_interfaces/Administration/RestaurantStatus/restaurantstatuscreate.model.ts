//import {Restaurant} from '../Restaurant/restaurant.model';

export interface CreateRestaurantStatus{
    restaurantStatus:string;
   // restaurantId?: Restaurant;
}