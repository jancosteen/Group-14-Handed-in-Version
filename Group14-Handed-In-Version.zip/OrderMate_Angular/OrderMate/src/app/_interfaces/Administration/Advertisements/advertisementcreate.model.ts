export interface CreateAdvertisement {
    advertisementName: string;
    advertisementDescription: string;
    advertisementFile: any;
}