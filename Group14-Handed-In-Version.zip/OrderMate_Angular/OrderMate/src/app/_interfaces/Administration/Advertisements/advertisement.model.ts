export interface Advertisement {
    advertisementId: number;
    advertisementName: string;
    advertisementDescription: string;
    advertisementFile: any;
}
