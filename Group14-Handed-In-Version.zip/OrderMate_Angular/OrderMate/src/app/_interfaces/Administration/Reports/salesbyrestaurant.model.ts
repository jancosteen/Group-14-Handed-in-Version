export interface SalesbyRestaurant{
    menu_Item_Id:number;
    menu_Item_Name: string;
    menu_Item_Price: string;
    order_Date_Completed: number;
    restaurant_Id:number;
    restaurantName:string;
}