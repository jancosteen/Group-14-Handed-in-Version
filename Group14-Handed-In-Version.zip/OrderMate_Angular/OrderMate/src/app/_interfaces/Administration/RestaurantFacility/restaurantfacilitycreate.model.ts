export interface CreateRestaurantFacility {
  
    restaurantFacility1: string;
}