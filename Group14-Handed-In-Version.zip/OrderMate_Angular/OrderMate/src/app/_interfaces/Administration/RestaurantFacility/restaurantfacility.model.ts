export interface RestaurantFacility {
    restaurantFacilityId: number;
    restaurantFacility1: string;
}