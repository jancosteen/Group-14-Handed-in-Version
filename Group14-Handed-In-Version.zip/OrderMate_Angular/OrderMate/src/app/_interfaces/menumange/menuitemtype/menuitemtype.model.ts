export interface MenuItemType {
    menuItemTypeId:number;
    menuItemType: string;
}  