export interface CreateMenuItemType {
    menuItemType: string;
}