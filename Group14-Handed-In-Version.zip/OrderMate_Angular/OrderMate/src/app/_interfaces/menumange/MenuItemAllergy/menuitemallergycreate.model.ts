export interface CreateMenuItemAllergy{
    
}