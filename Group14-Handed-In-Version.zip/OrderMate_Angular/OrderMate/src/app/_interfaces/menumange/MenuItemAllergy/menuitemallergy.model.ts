export interface MenuItemAllergy{
    
}