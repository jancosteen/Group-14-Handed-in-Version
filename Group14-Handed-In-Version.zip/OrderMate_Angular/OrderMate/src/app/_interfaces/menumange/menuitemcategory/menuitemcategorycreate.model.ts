export interface CreateMenuItemCategory{
    menuItemCategory1:string;
}