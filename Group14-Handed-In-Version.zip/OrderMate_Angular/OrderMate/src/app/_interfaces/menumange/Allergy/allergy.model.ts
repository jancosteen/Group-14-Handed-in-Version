export interface Allergy{
    allergyId: string;
    allergy:string;
}