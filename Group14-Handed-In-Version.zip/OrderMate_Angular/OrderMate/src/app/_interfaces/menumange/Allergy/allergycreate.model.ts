export interface CreateAllergy{

    allergy:string;
}
