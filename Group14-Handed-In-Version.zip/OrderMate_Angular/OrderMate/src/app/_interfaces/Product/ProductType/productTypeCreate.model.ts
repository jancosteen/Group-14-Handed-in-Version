export interface ProductTypeCreate {
    
}