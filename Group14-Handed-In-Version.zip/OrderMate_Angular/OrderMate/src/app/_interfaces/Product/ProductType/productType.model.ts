export interface ProductType{
    ProductTypeId: string;
    ProductType1: string;
}