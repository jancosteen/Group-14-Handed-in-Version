export interface ProductWrittenOff{
    ProductWrittenOffId: String;
    WrittenOffQty: string;
    WrittenOffStockIdFk: string;
    ProductIdFk: string;
    Employee?: string;
}



