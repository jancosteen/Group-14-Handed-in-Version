export interface CreateProductWrittenOff{
    
    WrittenOffQty: string;
    WrittenOffStockIdFk: string;
    ProductIdFk: string;
    Employee?: string;
}