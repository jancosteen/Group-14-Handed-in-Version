export interface ReorderFreq {
    ReorderFreqId: string;
    ReorderFreq1: string;
}