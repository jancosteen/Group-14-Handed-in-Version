export interface StockTake {
    stocktakeId: number;
    stocktakeDate: Date;
}