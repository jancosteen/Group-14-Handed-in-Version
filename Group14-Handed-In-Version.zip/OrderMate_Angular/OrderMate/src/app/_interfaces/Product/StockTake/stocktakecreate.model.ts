export interface CreateStockTake {
    stocktakeDate: Date;
}