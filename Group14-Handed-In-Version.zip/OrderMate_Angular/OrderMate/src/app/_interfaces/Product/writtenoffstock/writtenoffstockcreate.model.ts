export interface CreateWrittenOffStock{

    WrittenOfStockDate: Date;
}