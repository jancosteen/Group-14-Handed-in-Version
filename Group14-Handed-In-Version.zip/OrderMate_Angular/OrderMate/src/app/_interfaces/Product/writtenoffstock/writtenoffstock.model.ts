export interface WrittenOffStock{
    WrittenOfStockId: number;
    WrittenOfStockDate: Date;
}