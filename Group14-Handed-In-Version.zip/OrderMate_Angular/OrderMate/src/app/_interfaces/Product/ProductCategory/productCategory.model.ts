export interface ProductCategory{
    ProductCategoryId: string;
    ProductCategory1: string;
}