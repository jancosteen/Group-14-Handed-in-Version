export interface CreateProductCategory {
    ProductCategory1: string;
}