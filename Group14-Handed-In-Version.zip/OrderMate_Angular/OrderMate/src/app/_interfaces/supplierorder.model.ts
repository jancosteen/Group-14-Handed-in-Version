export interface SupplierOrder{
    SupplierOrderId: string;
    SupplierOrderDate: Date;

    
    supplierId?: string;
}