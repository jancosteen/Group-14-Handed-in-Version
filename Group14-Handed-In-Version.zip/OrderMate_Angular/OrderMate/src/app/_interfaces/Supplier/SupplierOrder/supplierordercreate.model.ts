export interface CreateSupplierOrder {
    SupplierOrderDate: Date;
    supplierId?: string; 
}