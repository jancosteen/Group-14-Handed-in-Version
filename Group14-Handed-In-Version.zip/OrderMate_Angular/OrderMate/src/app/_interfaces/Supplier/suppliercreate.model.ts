export interface CreateSupplier {
  //  supplierId: string;
    supplierName: string;
    supplierDescription: string;
    supplierEmail: string;
    supplierContactNumber: string;
    supplierAddressLine1: string;
    supplierAddressLine2: string;
    supplierAddressLine3: string;
    supplierCity: string;
    supplierPostalCode: string;
    supplierCountry: string;
}