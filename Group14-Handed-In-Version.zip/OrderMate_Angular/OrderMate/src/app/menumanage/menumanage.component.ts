import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menumanage',
  templateUrl: './menumanage.component.html',
  styleUrls: ['./menumanage.component.css']
})
export class MenumanageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
