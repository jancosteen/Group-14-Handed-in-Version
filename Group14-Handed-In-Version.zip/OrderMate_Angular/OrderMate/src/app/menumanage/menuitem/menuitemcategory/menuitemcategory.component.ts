import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menuitemcategory',
  templateUrl: './menuitemcategory.component.html',
  styleUrls: ['./menuitemcategory.component.css']
})
export class MenuitemcategoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
