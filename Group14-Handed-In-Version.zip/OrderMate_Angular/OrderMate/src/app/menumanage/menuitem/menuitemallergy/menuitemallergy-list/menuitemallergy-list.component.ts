import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menuitemallergy-list',
  templateUrl: './menuitemallergy-list.component.html',
  styleUrls: ['./menuitemallergy-list.component.css']
})
export class MenuitemallergyListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
