import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menuitemprice-list',
  templateUrl: './menuitemprice-list.component.html',
  styleUrls: ['./menuitemprice-list.component.css']
})
export class MenuitempriceListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
