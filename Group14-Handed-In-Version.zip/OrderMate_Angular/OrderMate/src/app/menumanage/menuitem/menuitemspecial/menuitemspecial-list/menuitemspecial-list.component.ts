import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menuitemspecial-list',
  templateUrl: './menuitemspecial-list.component.html',
  styleUrls: ['./menuitemspecial-list.component.css']
})
export class MenuitemspecialListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
