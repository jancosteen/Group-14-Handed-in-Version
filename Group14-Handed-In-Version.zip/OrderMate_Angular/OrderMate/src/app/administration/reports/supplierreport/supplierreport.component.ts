import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-supplierreport',
  templateUrl: './supplierreport.component.html',
  styleUrls: ['./supplierreport.component.css']
})
export class SupplierreportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
