import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-restaurantstatus',
  templateUrl: './restaurantstatus.component.html',
  styleUrls: ['./restaurantstatus.component.css']
})
export class RestaurantstatusComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
