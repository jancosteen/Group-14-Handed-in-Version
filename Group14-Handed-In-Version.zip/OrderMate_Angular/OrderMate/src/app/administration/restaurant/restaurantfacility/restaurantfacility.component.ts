import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-restaurantfacility',
  templateUrl: './restaurantfacility.component.html',
  styleUrls: ['./restaurantfacility.component.css']
})
export class RestaurantfacilityComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
