import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employeemanage',
  templateUrl: './employeemanage.component.html',
  styleUrls: ['./employeemanage.component.css']
})
export class EmployeemanageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
