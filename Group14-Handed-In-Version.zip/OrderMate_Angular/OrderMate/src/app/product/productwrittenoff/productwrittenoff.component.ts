import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-productwrittenoff',
  templateUrl: './productwrittenoff.component.html',
  styleUrls: ['./productwrittenoff.component.css']
})
export class ProductwrittenoffComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
