import { Component, OnInit, OnDestroy, ViewChild  } from '@angular/core';




@Component({
  selector: 'app-specialprice',
  templateUrl: './specialprice.component.html',
  styleUrls: ['./specialprice.component.css']
})
export class SpecialpriceComponent implements OnInit{ 


  constructor() { }
 


  ngOnInit(): void {
 
    

  }
  

 


}
