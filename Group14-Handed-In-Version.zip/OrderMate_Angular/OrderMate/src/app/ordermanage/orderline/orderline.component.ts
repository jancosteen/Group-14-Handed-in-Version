import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-orderline',
  templateUrl: './orderline.component.html',
  styleUrls: ['./orderline.component.css']
})
export class OrderlineComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
