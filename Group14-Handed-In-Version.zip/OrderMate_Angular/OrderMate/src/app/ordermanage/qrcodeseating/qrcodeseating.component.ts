import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-qrcodeseating',
  templateUrl: './qrcodeseating.component.html',
  styleUrls: ['./qrcodeseating.component.css']
})
export class QrcodeseatingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
