export interface LoginUser{
    username: string;
    password: string;
}