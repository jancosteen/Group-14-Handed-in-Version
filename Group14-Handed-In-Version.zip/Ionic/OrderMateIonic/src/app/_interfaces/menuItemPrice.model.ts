export interface MenuItemPrice {
    menuItemPriceId:number;
    menuItemPrice1:number;
    menuItemDateUpdated:string;
    menuItemIdFk?:number;
}