export interface MenuItemCategory{
    menuItemCategoryId:number;
    menuItemCategory1:string;
}