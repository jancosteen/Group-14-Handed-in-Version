export interface qrCodeSeating{
    nrOfPeople:number;
    qrCodeIdFk:number;
    seatingIdFk:number;
    orderIdFk?:number;
}