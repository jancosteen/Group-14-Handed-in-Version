export interface User{
    userName:string;
    userRole:string;
}