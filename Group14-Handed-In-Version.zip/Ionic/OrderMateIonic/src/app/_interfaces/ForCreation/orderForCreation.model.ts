export interface OrderForCreation{
    orderDateCreated:string;
    orderDateCompleted?:string;
    qrCodeSeatingIdFk?:number;
    //orderStatus?:number;
}