export const environment = {
  production: true,
  urlAddress: 'http://www.ordermate.com'
};
